import React from 'react';
import Header from '../components/layout/Header'; // Updated path
import Hero from '../components/layout/Hero'; // Updated path
import Features from '../components/layout/Features'; // Updated path
import HowItWorks from '../components/layout/HowItWorks'; // Updated path
import Pricing from '../components/layout/Pricing'; // Updated path
import Industries from '../components/layout/Industries'; // Updated path
import Integrations from '../components/layout/Integrations'; // Updated path
import Resources from '../components/layout/Resources'; // Updated path
import FAQs from '../components/layout/FAQs'; // Updated path
import Footer from '../components/layout/Footer'; // Updated path
import '../components/styles/global.css';

const HomePage = () => {
  return (
    <div className="home-page">
      <Header />
      <Hero />
      <Features />
      <HowItWorks />
      <Pricing />
      <Industries />
      <Integrations />
      <Resources />
      <FAQs />
      <Footer />
    </div>
  );
};

export default HomePage;