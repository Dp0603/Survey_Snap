import React from "react";
import HomePage from "./pages/HomePage";
import axios from "axios";
import { useEffect, useState } from "react";
import { Route, Routes, useLocation } from "react-router-dom";
import { Login } from "./components/common/Login";
import { Signup } from "./components/common/Signup";
import PrivateRoutes from "./hooks/PrivateRoutes";
import Sitemap from "./components/layout/Sitemap";
import ScrollToTop from "./components/ScrollToTop"; // Import the ScrollToTop component

function App() {
  const [count, setCount] = useState(0);
  axios.defaults.baseURL = "http://localhost:3000";
  const location = useLocation();

  useEffect(() => {
    if (location.pathname === "/login" || location.pathname === "/signup") {
      document.body.className = "";
    } else {
      document.body.className =
        "layout-fixed sidebar-expand-lg bg-body-tertiary sidebar-open app-loaded";
    }
  }, [location.pathname]);

  return (
    <div className="App">
      <body className="layout-fixed sidebar-expand-lg bg-body-tertiary app-loaded sidebar-open">
        <ScrollToTop /> {/* Add ScrollToTop here */}
        <Routes>
          {/* HomePage and other routes */}
          <Route
            path="/"
            element={
              <div className="app-wrapper">
                <HomePage />
              </div>
            }
          />
          <Route path="/home" element={<HomePage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/sitemap" element={<Sitemap />} /> {/* Full-page sitemap */}
          <Route path="" element={<PrivateRoutes />} />
        </Routes>
      </body>
    </div>
  );
}

export default App;