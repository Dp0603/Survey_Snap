import React from 'react';
import '../styles/Hero.css';

const Hero = () => {
  return (
    <section className="hero">
      <div className="hero-content">
        <h1 className="animated-text">The Complete Survey Solution</h1>
        <p className="animated-subtext">
          Create engaging surveys, analyze data, and produce visual reports with SurveySnap.
        </p>
        <button className="cta animated-button">Get Started</button>
      </div>
    </section>
  );
};

export default Hero;